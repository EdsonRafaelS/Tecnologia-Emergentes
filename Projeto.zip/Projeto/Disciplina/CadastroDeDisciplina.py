import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import sys
sys.path.append('C:/TDS - 3 MODULO/TECNOLOGIAS EMERGENTES/SEGUNDO BIMESTRE/Projeto')

from BancoDeDados import cadastrar_disciplina
from BancoDeDados import carregar_disciplinas_do_banco
from BancoDeDados import remover_disciplina_do_banco
from BancoDeDados import atualizar_disciplina_no_banco

#Funções
def cadastrar_disciplina_no_bd():
    nome = nome_entry.get()
    carga_horaria = cargaH_entry.get()
    nivel_disciplina = Button_nivel.get()

    # Chama a função do BancoDeDados.py para cadastrar a disciplina
    id_disciplina = cadastrar_disciplina(nome, carga_horaria, nivel_disciplina)

    # Limpar os campos após cadastrar
    nome_entry.delete(0, tk.END)
    cargaH_entry.delete(0, tk.END)
    Button_nivel.set('')  # ou o valor padrão desejado

    # Atualizar a Treeview com os dados atualizados
    carregar_e_exibir_dados()
    
def carregar_e_exibir_dados():
    # Limpar dados existentes na Treeview
    for item in tree.get_children():
        tree.delete(item)

    # Carregar dados do banco
    dados = carregar_disciplinas_do_banco()

    # Adicionar dados à Treeview
    for dado in dados:
        tree.insert("", "end", values=dado)

def remover_disciplina_selecionada():
    # Obter item selecionado na Treeview
    item_selecionado = tree.selection()

    if item_selecionado:
        # Obter ID da disciplina a partir do item selecionado
        id_disciplina = tree.item(item_selecionado, 'values')[0]

        # Chamar a função para remover a disciplina do banco de dados
        remover_disciplina_do_banco(id_disciplina)

        # Recarregar os dados na Treeview
        carregar_e_exibir_dados()
    else:
        print("Selecione uma disciplina para remover.")
    
def alterar_dados():
    selected_item = tree.selection()

    if not selected_item:
        messagebox.showwarning('Aviso', 'Selecione uma linha para editar.')
        return

    # Obter dados da linha selecionada
    id_disciplina, nome, carga_horaria, nivel_disciplina = tree.item(selected_item, 'values')

    # Remover a linha selecionada da Treeview
    tree.delete(selected_item)

    # Preencher os campos com os dados existentes
    nome_entry.delete(0, tk.END)
    nome_entry.insert(0, nome)
    cargaH_entry.delete(0, tk.END)
    cargaH_entry.insert(0, carga_horaria)
    Button_nivel.set(nivel_disciplina)

    # Atualizar a função do botão "Cadastrar" para editar a disciplina
    def adicionar_disciplina_editada():
        # Obter os novos dados dos campos
        novo_nome = nome_entry.get()
        nova_carga_horaria = cargaH_entry.get()
        novo_nivel_disciplina = Button_nivel.get()

        if not (novo_nome and nova_carga_horaria and novo_nivel_disciplina):
            messagebox.showwarning('Aviso', 'Preencha todos os campos antes de adicionar ou alterar.')
            return

        # Atualizar a disciplina no banco de dados
        atualizar_disciplina_no_banco(id_disciplina, novo_nome, nova_carga_horaria, novo_nivel_disciplina)

        # Adicionar à Treeview apenas se a atualização for bem-sucedida
        tree.insert("", "end", values=(id_disciplina, novo_nome, novo_nivel_disciplina, nova_carga_horaria))

        # Limpar os campos após adicionar
        nome_entry.delete(0, tk.END)
        cargaH_entry.delete(0, tk.END)
        Button_nivel.set('')  # ou o valor padrão desejado

    # Atualizar a função do botão "Cadastrar"
    button_cadastrar.configure(command=adicionar_disciplina_editada)

def sair():
    root.destroy()


root = tk.Tk()
root.title('Cadastro de disciplinas')
root.geometry('700x600+100+50')

# Adicione um evento ao widget principal para chamar a função ao abrir a tela
root.bind('<Map>', lambda event: carregar_e_exibir_dados())

# criando frame
frame = tk.Frame(root, border=1, relief=tk.RAISED)
frame.grid()

nome_frame = tk.Frame(root)
nome_frame.grid()

label_nome = tk.Label(nome_frame, text="Nome da disciplina:")
label_nome.grid(row=0, column=0, padx=85, pady=15)

nome_entry = tk.Entry(nome_frame, bd=3)
nome_entry.grid(row=0, column=1)

# carga horaria
cargaH_frame = tk.Frame(root)
cargaH_frame.grid()

label_cargaH = tk.Label(cargaH_frame, text="Carga horária:")
label_cargaH.grid(row=0, column=0, padx=100, pady=15)

cargaH_entry = tk.Entry(cargaH_frame, bd=3)
cargaH_entry.grid(row=0, column=1)

# combox nivel disciplina
nivel_frame = tk.Frame(root)
nivel_frame.grid()

label_nivel = tk.Label(nivel_frame, text="Nível da disciplina:")
label_nivel.grid(row=0, column=0, padx=85, pady=15, sticky=tk.E)

Button_nivel = ttk.Combobox(nivel_frame, state="readonly")
Button_nivel['values'] = ('Ensino Médio', 'Técnico Subsequente', 'Superior')
Button_nivel.current(2)
Button_nivel.grid(row=0, column=1, padx=0)

# Botões (Cadastrar, Alterar, Remover, Cancelar)
botoes_frame = tk.Frame(root)
botoes_frame.grid()

button_cadastrar = tk.Button(botoes_frame, text="Cadastrar",  )
button_cadastrar.configure(command=cadastrar_disciplina_no_bd)
button_cadastrar.grid(row=0, column=0, padx=10)

button_alterar = tk.Button(botoes_frame, text="Alterar", )
button_alterar.configure(command=alterar_dados)
button_alterar.grid(row=0, column=1, padx=10, pady=10)

button_remover = tk.Button(botoes_frame, text="Remover", )
# Configurar o comando do botão Remover
button_remover.configure(command=remover_disciplina_selecionada)
button_remover.grid(row=0, column=2, padx=10)

button_cancelar = tk.Button(botoes_frame, text="Cancelar", )
button_cancelar.configure(command=sair)
button_cancelar.grid(row=0, column=3, padx=10)

# Configurar o layout da janela
frame.grid(row=0, column=0, pady=10)  # Ajuste o valor de pady conforme necessário
nome_frame.grid(row=1, column=0)
cargaH_frame.grid(row=2, column=0)
nivel_frame.grid(row=3, column=0)
botoes_frame.grid(row=4, column=0)


# Criar Treeview com 4 colunas
tree = ttk.Treeview(root, columns=("Coluna1", "Coluna2", "Coluna3", "Coluna4"), show="headings")

# Configurar cabeçalhos das colunas
tree.heading("Coluna1", text="ID")
tree.heading("Coluna2", text="Nome da Disciplina")
tree.heading("Coluna3", text="Nível da Disciplina")
tree.heading("Coluna4", text="Carga horária")


# Ajustar a largura das colunas
tree.column("Coluna1", width=100)
tree.column("Coluna2", width=200)
tree.column("Coluna3", width=150)
tree.column("Coluna4", width=100)


# Adicionar barra de rolagem
scrollbar = ttk.Scrollbar(root, orient="vertical", command=tree.yview)
tree.configure(yscroll=scrollbar.set)

# Posicionar Treeview e barra de rolagem na janela
tree.grid(row=5, column=0, sticky="nsew")
scrollbar.grid(row=5, column=1, sticky="ns")

# Configurar o layout da janela
root.grid_rowconfigure(5, weight=1)
root.grid_columnconfigure(0, weight=1)

tk.mainloop()