import tkinter as tk
from tkinter import ttk
import subprocess
from tkinter import PhotoImage
from PIL import Image, ImageTk

#Logo abaixo estará todas
#Função para abrir a tela de Gerenciar Ofertas da pasta Semestre
def AbrirGerenciarOfertas():
    caminho = 'C:\\TDS - 3 MODULO\\TECNOLOGIAS EMERGENTES\\SEGUNDO BIMESTRE\\Projeto\\Semestre\\CadastroDeOfertas.py'
    
    subprocess.Popen(["Python", caminho])
    
    

#Função para abrir a tela de Gerenciar Semestre da pasta Semestre
def AbrirGerenciarSemestre():
    caminho = 'C:\\TDS - 3 MODULO\\TECNOLOGIAS EMERGENTES\\SEGUNDO BIMESTRE\\Projeto\\Semestre\\CadastroSemestre.py'
    
    subprocess.Popen(["Python", caminho])
    
    

#Função para abrir a tela de Gerenciar Disciplina da pasta Disciplina
def AbrirGerenciarDisciplina():
    caminho = 'C:\\TDS - 3 MODULO\\TECNOLOGIAS EMERGENTES\\SEGUNDO BIMESTRE\\Projeto\\Disciplina\\CadastroDeDisciplina.py'  
    
    subprocess.Popen(["Python", caminho])
    
#Função para abrir a tela de Gerador de Conteudo na pasta Conteudo
def AbrirGerenciarConteudo():
    caminho = 'C:\\TDS - 3 MODULO\\TECNOLOGIAS EMERGENTES\\SEGUNDO BIMESTRE\\Projeto\\Conteudo\\GestaoDeConteudoDasAulas.py'  
    
    subprocess.Popen(["Python", caminho]) 
    
#Função para abrir a tela de Gerador de Conteudo na pasta Conteudo
def AbrirGerenciarCronograma():
    caminho = 'C:\\TDS - 3 MODULO\\TECNOLOGIAS EMERGENTES\\SEGUNDO BIMESTRE\\Projeto\\Cronograma\\GeradorDeCronograma.py'  
    
    subprocess.Popen(["Python", caminho])    

#Função para abrir a tela de Gerador de Conteudo na pasta Conteudo
def CadastroDeDatasImportantes():
    caminho = 'C:\\TDS - 3 MODULO\\TECNOLOGIAS EMERGENTES\\SEGUNDO BIMESTRE\\Projeto\\Calendario\\CadastroDeDatasImportantes.py'  
    
    subprocess.Popen(["Python", caminho])  
def SairDaPagina():
    root.destroy()

#Configurações da pagina
root = tk.Tk()
root.title('Geração de Cronometro')
root.geometry('1300x250')
#root.resizable(False,False)

#Criando o button Gerencia Ofertas
img_ofertas = PhotoImage(file='C:\TDS - 3 MODULO\TECNOLOGIAS EMERGENTES\SEGUNDO BIMESTRE\Projeto\TelaInicial\img/ofertas.png')
button_ofertas = tk.Button(root, text='Gerenciar Ofertas', image=img_ofertas, compound='top', command=lambda: AbrirGerenciarOfertas())  
button_ofertas.grid(row=0, column=0, padx=10, pady=20, ipadx=15, ipady=15)

#Criando o button Gerenciar Semestre
img_semestre = PhotoImage(file='C:\TDS - 3 MODULO\TECNOLOGIAS EMERGENTES\SEGUNDO BIMESTRE\Projeto\TelaInicial\img/semestre.png')
button_semestre = tk.Button(root, text='Gerenciar Semestres', image=img_semestre, compound='top', command=lambda : AbrirGerenciarSemestre())
button_semestre.grid(row=0, column=1, padx=10, pady=20, ipadx=15, ipady=15)

#Criando o button Gerenciar Disciplinas
img_disciplinas = PhotoImage(file='C:\TDS - 3 MODULO\TECNOLOGIAS EMERGENTES\SEGUNDO BIMESTRE\Projeto\TelaInicial\img/disciplina.png')
button_disciplina = tk.Button(root, text='Gerenciar Disciplinas', image=img_disciplinas, compound='top', command=lambda: AbrirGerenciarDisciplina())
button_disciplina.grid(row=0, column=2, padx=10, pady=20, ipadx=15, ipady=15)

#Criando o button Gerenciar Cronograma
img_cronograma = PhotoImage(file='C:\TDS - 3 MODULO\TECNOLOGIAS EMERGENTES\SEGUNDO BIMESTRE\Projeto\TelaInicial\img/cronograma.png')
button_cronograma = tk.Button(root, text='Gerenciar Cronograma', image=img_cronograma, compound='top', command=lambda: AbrirGerenciarCronograma())
button_cronograma.grid(row=0, column=3, padx=10, pady=20, ipadx=15, ipady=15)

#Criando o button Gerenciar Conteudo
img_conteudo = PhotoImage(file='C:\TDS - 3 MODULO\TECNOLOGIAS EMERGENTES\SEGUNDO BIMESTRE\Projeto\TelaInicial\img/conteudo.png')
button_conteudo = tk.Button(root, text='Gerenciar Conteudo', image=img_conteudo, compound='top', command=lambda: AbrirGerenciarConteudo())
button_conteudo.grid(row=0, column=4, padx=10, pady=20, ipadx=15, ipady=15)

#Criando o button Cadastro de Datas Importantes
img_DatasImportantes = PhotoImage(file='C:\TDS - 3 MODULO\TECNOLOGIAS EMERGENTES\SEGUNDO BIMESTRE\Projeto\TelaInicial\img/evento.png')
button_DatasImportantes = tk.Button(root, text='Datas Importantes', image=img_DatasImportantes, compound='top', command=lambda: CadastroDeDatasImportantes())
button_DatasImportantes.grid(row=0, column=5, padx=10, pady=20, ipadx=15, ipady=15)

#Criando o button Sair
img_sair = PhotoImage(file='C:\TDS - 3 MODULO\TECNOLOGIAS EMERGENTES\SEGUNDO BIMESTRE\Projeto\TelaInicial\img/sair.png')
button_sair = tk.Button(root, text='Sair', image=img_sair, compound='top', command=lambda: SairDaPagina())
button_sair.grid(row=0, column=6, padx=10, pady=20, ipadx=15, ipady=15)

#Iniciando a pagina
root.mainloop()