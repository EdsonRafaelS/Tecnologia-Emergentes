import tkinter as tk
from tkinter import ttk
from tkinter import *
from tkinter import messagebox
import sys
sys.path.append('C:/TDS - 3 MODULO/TECNOLOGIAS EMERGENTES/SEGUNDO BIMESTRE/Projeto')
import BancoDeDados
from BancoDeDados import obter_anos_do_banco
from BancoDeDados import obter_nomes_disciplinas
from BancoDeDados import obter_semestres_do_ano
from BancoDeDados import obter_niveis_por_disciplina
from BancoDeDados import obter_id_semestre_do_banco
from BancoDeDados import obter_id_disciplina_do_banco
from BancoDeDados import inserir_oferta_no_banco
from BancoDeDados import obter_ofertas_do_banco
from BancoDeDados import excluir_oferta_do_banco


# Função chamada quando o ano é selecionado no combobox
def ano_selecionado(event=None):
     # Limpar o combobox do semestre
    button_semestre.set('')
    
    # Obter o ano selecionado no combobox do ano
    ano_selecionado = button_ano.get()

    # Verificar se um ano foi selecionado
    if ano_selecionado:
        # Obter os semestres 1 e 2 associados ao ano
        semestres_do_ano = obter_semestres_do_ano(ano_selecionado)
        # Preencher o combobox do semestre com os semestres obtidos
        button_semestre['values'] = semestres_do_ano

        # Chamar a função para preencher a treeview com as ofertas
        preencher_treeview_ofertas()

# Função chamada quando o semestre é selecionado no combobox
def semestre_selecionado(event=None):
    # Obter o ano, semestre e disciplina selecionados nos comboboxes
    ano_selecionado = button_ano.get()
    semestre_selecionado = button_semestre.get()
    disciplina_selecionada = button_disciplina.get()

    # Verificar se um ano, um semestre e uma disciplina foram selecionados
    if ano_selecionado and semestre_selecionado and disciplina_selecionada:
        # Obter os níveis associados ao ano, semestre e disciplina
        niveis_da_disciplina = obter_niveis_por_disciplina(ano_selecionado, semestre_selecionado, disciplina_selecionada)

        # Preencher o combobox do nível com os níveis obtidos
        button_NivelDeEnsino['values'] = niveis_da_disciplina
        
        # Chamar a função para preencher a treeview com as ofertas
        preencher_treeview_ofertas()

def disciplina_selecionada(event=None):
    # Limpar o combobox do nível
    button_NivelDeEnsino.set('')
    
    # Obter a disciplina selecionada no combobox de disciplina
    disciplina_selecionada = button_disciplina.get()

    # Verificar se uma disciplina foi selecionada
    if disciplina_selecionada:
        # Preencher o combobox do nível com os níveis associados à disciplina
        niveis_da_disciplina = obter_niveis_por_disciplina(disciplina_selecionada)
        button_NivelDeEnsino['values'] = niveis_da_disciplina

        # Tornar o botão "Preencher Níveis" visível
        button_preencher_niveis.grid()
    else:
        # Ocultar o botão "Preencher Níveis"
        button_preencher_niveis.grid_remove()

# Função chamada ao pressionar o botão "Salvar"
def salvar_oferta():
    # Obtenha os valores selecionados nos comboboxes
    id_semestre = obter_id_semestre_selecionado()
    id_disciplina = obter_id_disciplina_selecionada()
    nivel = button_NivelDeEnsino.get()  # ou obter o valor de acordo com a sua implementação

    # Verifique se todos os campos necessários foram preenchidos
    if id_semestre and id_disciplina and nivel:
        # Chame a função para salvar os dados no banco de dados
        # Substitua esta chamada pela sua própria implementação
        salvar_dados_oferta(id_semestre, id_disciplina, nivel)
        messagebox.showinfo("Sucesso", "Oferta salva com sucesso!")
        # Antes de iniciar o loop principal (root.mainloop()), chame a função para preencher a treeview inicialmente
        preencher_treeview_ofertas()
    else:
        messagebox.showerror("Erro", "Preencha todos os campos antes de salvar.")

# Função para obter o ID do semestre selecionado
def obter_id_semestre_selecionado():
    ano_selecionado = button_ano.get()
    semestre_selecionado = button_semestre.get()

    # Substitua esta chamada pela sua própria implementação
    # que retorna o ID do semestre com base no ano e semestre selecionados
    id_semestre = obter_id_semestre_do_banco(ano_selecionado, semestre_selecionado)
    return id_semestre

# Função para obter o ID da disciplina selecionada
def obter_id_disciplina_selecionada():
    disciplina_selecionada = button_disciplina.get()

    # Substitua esta chamada pela sua própria implementação
    # que retorna o ID da disciplina com base no nome selecionado
    id_disciplina = obter_id_disciplina_do_banco(disciplina_selecionada)
    return id_disciplina

# Função para salvar os dados da oferta no banco de dados
def salvar_dados_oferta(id_semestre, id_disciplina, nivel):
    # Substitua esta chamada pela sua própria implementação
    # que insere os dados da oferta na tabela "Ofertas"
    inserir_oferta_no_banco(id_semestre, id_disciplina, nivel)

# Função para preencher a treeview com as ofertas
def preencher_treeview_ofertas():
    # Limpar a treeview antes de preencher novamente
    for item in treeview_conteudo.get_children():
        treeview_conteudo.delete(item)

    # Obter as ofertas do banco de dados
    ofertas = obter_ofertas_do_banco()

    # Preencher a treeview com as informações obtidas
    for oferta in ofertas:
        treeview_conteudo.insert('', 'end', values=oferta)

# Função para excluir uma oferta
def excluir_oferta_selecionada():
    # Obter o item selecionado na treeview
    selecionado = treeview_conteudo.selection()

    if not selecionado:
        messagebox.showwarning("Aviso", "Selecione uma oferta para excluir.")
        return

    # Obter o ID da oferta selecionada
    id_oferta_selecionada = treeview_conteudo.item(selecionado, 'values')[0]

    # Confirmar a exclusão
    resposta = messagebox.askyesno("Confirmação", "Tem certeza que deseja excluir esta oferta?")

    if resposta:
        # Chamar a função para excluir a oferta do banco de dados
        excluir_oferta_do_banco(id_oferta_selecionada)

        # Chamar a função para preencher novamente a treeview após a exclusão
        preencher_treeview_ofertas()

def sair():
    root.destroy()

# Codigo de criação da tela
root = tk.Tk()
root.title('Cadastro de Ofertas')
root.geometry('820x400')  # Tamanho principal da tela
root.resizable(False, False)  # Não permite redimensionar

# Label do ano
label_ano = ttk.Label(root, text='Ano:')  # Nome que irá ficar acima do botão
label_ano.grid(column=0, row=0, sticky=tk.N)  # Posicionando o elemento

# Criar combobox do ano
button_ano = ttk.Combobox(root, state="readonly")
button_ano.grid(column=0, row=1)

# Preencher combobox com os anos do banco
anos_do_banco = obter_anos_do_banco()
button_ano['values'] = anos_do_banco

# Associar a função ano_selecionado ao evento de seleção do combobox do ano
button_ano.bind("<<ComboboxSelected>>", ano_selecionado)

# Label de semestre
label_semestre = ttk.Label(root, text='Semestre:')  # Nome que irá ficar acima do botão
label_semestre.grid(column=1, row=0)  # Posicionando o elemento

# Criar combobox do semestre
button_semestre = ttk.Combobox(root, state="readonly")
button_semestre.grid(column=1, row=1)

# Botão para preencher o combobox do semestre (invisível e automático)
button_preencher_semestres = tk.Button(root, text='Preencher Semestres', command=ano_selecionado)
button_preencher_semestres.grid(column=2, row=1)
button_preencher_semestres.invoke()  # Chama automaticamente a função associada ao botão
button_preencher_semestres.grid_remove()  # Remove o botão (torna invisível)


# Label da disciplina
label_disciplina = ttk.Label(root, text='Disciplina:')
label_disciplina.grid(column=2, row=0)

# Criar combobox da disciplina
button_disciplina = ttk.Combobox(root, state="readonly")
button_disciplina.grid(column=2, row=1)

# Preencher combobox com os nomes das disciplinas do banco
nomes_disciplinas = obter_nomes_disciplinas()
button_disciplina['values'] = nomes_disciplinas
# Associar a função disciplina_selecionada ao evento de seleção do combobox de disciplina
button_disciplina.bind("<<ComboboxSelected>>", disciplina_selecionada)

# Label da disciplina
label_nivelDeEnsino = ttk.Label(root, text='NíveL:')
label_nivelDeEnsino.grid(column=3, row=0)

# Criar combobox do nível de disciplina
button_NivelDeEnsino = ttk.Combobox(root, state="readonly")
button_NivelDeEnsino.grid(column=3, row=1)

# Botão para preencher o combobox do nível (invisível e automático)
button_preencher_niveis = tk.Button(root, text='Preencher Níveis', command=semestre_selecionado)
button_preencher_niveis.grid(column=4, row=1)
button_preencher_niveis.invoke()  # Chama automaticamente a função associada ao botão
button_preencher_niveis.grid_remove()  # Remove o botão (torna invisível)

# Treelview
colunas = ('Ano', 'Semestre', 'Disciplina', 'Nível')

# Crie o TreeView com colunas e cabeçalhos
treeview_conteudo = ttk.Treeview(root, columns=colunas, show='headings')

# Configurar os cabeçalhos das colunas
for coluna in colunas:
    treeview_conteudo.heading(coluna, text=coluna)

# Exibir o TreeView
treeview_conteudo.grid(rowspan=2, columnspan=4, row=4, column=0, padx=8)

# Botão de Salvar
button_salvar = tk.Button(root, text='Salvar', bg='gray', command=salvar_oferta)
button_salvar.grid(row=5, column=1, sticky=tk.S, ipadx=20, ipady=10)

# Botão de Excluir
button_excluir = tk.Button(root, text='Excluir', bg='gray', command=excluir_oferta_selecionada)
button_excluir.grid(row=5, column=2, sticky=tk.SW, ipadx=15, ipady=10)

# Botão de Cancelar
button_cancelar = tk.Button(root, text='Cancelar', bg='gray', command=sair)
button_cancelar.grid(row=5, column=2, sticky=tk.SE, ipadx=10, ipady=10)

# Antes de iniciar o loop principal (root.mainloop()), chame a função para preencher a treeview inicialmente
preencher_treeview_ofertas()
root.grid_columnconfigure(4, weight=212)  # Posicionamento fixo da página
root.grid_rowconfigure(4, weight=100)  # Posicionamento fixo da página
root.mainloop()
