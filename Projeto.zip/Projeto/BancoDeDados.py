import psycopg2
from psycopg2 import sql
import tkinter as tk
from tkinter import messagebox
 
parametros = {
    "host": "localhost",  # Servidor
    "dbname": "projeto_te",  # Nome do banco de dados
    "user": "postgres",  # Nome do usuario
    "password": "1234"  # Senha do PGAdmin
}
def conecta_bd():
    conexao = None
    try:  # Tente fazer alguma coisa
        conexao = psycopg2.connect(**parametros)  # Tentar fazer uma conexão com o Banco de Dados
        print('Conexão realizada com sucesso!')
    except Exception as erro:  # Exceção  # As erro (mostrar qual é o erro na conexão)
        print('Não foi possivel conectar ao BD!', erro)
    return conexao


# Inicio Funções da Tela Cadastro de Datas Importantes (Edson Rafael)

def adicionar_data_ao_banco(data, descricao, tipo_data):
    conexao = conecta_bd()
    id_data_importante = None  # Inicializa com None para lidar com possíveis erros
    try:
        with conexao:
            with conexao.cursor() as cursor:
                cursor.execute(
                    sql.SQL("INSERT INTO Datas_Importantes (dia_data, descricao, tipo_data) VALUES (%s, %s, %s) RETURNING id_data_importante;"),
                    (data, descricao, tipo_data)
                )
                # Obter o ID após a inserção
                id_data_importante = cursor.fetchone()[0]
                print(f'Data adicionada com sucesso! ID: {id_data_importante}')
    except Exception as erro:
        print(f'Erro ao adicionar data: {erro}')
    finally:
        if conexao:
            conexao.close()

    return id_data_importante


def apagar_data_do_banco(id_data_importante):
    conexao = conecta_bd()
    try:
        with conexao:
            with conexao.cursor() as cursor:
                cursor.execute(
                    sql.SQL("DELETE FROM Datas_Importantes WHERE id_data_importante = %s;"),
                    (id_data_importante,)
                )
                print(f'Data removida do banco com sucesso! ID: {id_data_importante}')
    except Exception as erro:
        print(f'Erro ao remover data do banco: {erro}')
    finally:
        if conexao:
            conexao.close()
            
def atualizar_data_no_banco(id_data_importante, nova_data, nova_descricao, novo_tipo_data):
    conexao = conecta_bd()
    try:
        with conexao:
            with conexao.cursor() as cursor:
                cursor.execute(
                    sql.SQL("UPDATE Datas_Importantes SET dia_data = %s, descricao = %s, tipo_data = %s WHERE id_data_importante = %s;"),
                    (nova_data, nova_descricao, novo_tipo_data, id_data_importante)
                )
                print(f'Dados atualizados no banco com sucesso! ID: {id_data_importante}')
    except Exception as erro:
        print(f'Erro ao atualizar dados no banco: {erro}')
    finally:
        if conexao:
            conexao.close()

def carregar_dados_do_banco():
    conexao = conecta_bd()
    dados = []
    try:
        with conexao:
            with conexao.cursor() as cursor:
                cursor.execute("SELECT id_data_importante, dia_data, descricao, tipo_data FROM Datas_Importantes;")
                rows = cursor.fetchall()
                dados = [(row[0], row[1], row[2], row[3]) for row in rows]

    except Exception as erro:
        print(f'Erro ao carregar dados do banco: {erro}')
    finally:
        if conexao:
            conexao.close()

    return dados

def atualizar_disciplina_no_banco(id_disciplina, novo_nome, nova_carga_horaria, novo_nivel_disciplina):
    conexao = conecta_bd()
    try:
        with conexao:
            with conexao.cursor() as cursor:
                cursor.execute(
                    sql.SQL("UPDATE Disciplinas SET nome = %s, carga_horaria = %s, nivel_disciplina = %s WHERE id_disciplina = %s;"),
                    (novo_nome, nova_carga_horaria, novo_nivel_disciplina, id_disciplina)
                )
                print(f'Disciplina atualizada no banco com sucesso! ID: {id_disciplina}')
    except Exception as erro:
        print(f'Erro ao atualizar disciplina no banco: {erro}')
    finally:
        if conexao:
            conexao.close()
# Final da Funções da Tela Cadastro de Datas Importantes (Edson Rafael)

# Inicio Funções da Tela Cadastrar Oferta (Edson Rafael) 
def obter_anos_do_banco():
    conexao = conecta_bd()

    if conexao:
        try:
            cursor = conexao.cursor()
            consulta = "SELECT DISTINCT ano FROM Semestre ORDER BY ano"
            cursor.execute(consulta)
            anos = [ano[0] for ano in cursor.fetchall()]
            cursor.close()
            conexao.close()
            return anos
        except Exception as erro:
            print(f"Erro ao obter anos do banco de dados: {erro}")
            return []
    return []

def obter_semestres_do_ano(ano):
    conexao = conecta_bd()

    if conexao:
        try:
            cursor = conexao.cursor()
            consulta = "SELECT DISTINCT semestre FROM Semestre WHERE ano = %s ORDER BY semestre"
            cursor.execute(consulta, (ano,))
            semestres = [semestre[0] for semestre in cursor.fetchall()]
            cursor.close()
            conexao.close()
            return semestres
        except Exception as erro:
            print(f"Erro ao obter semestres do banco de dados para o ano {ano}: {erro}")
            return []
    return []

# Adicione estas linhas no final de BancoDeDados.py
anos_do_banco = obter_anos_do_banco()
print("Anos encontrados:", anos_do_banco)

for ano in anos_do_banco:
    semestres_do_ano = obter_semestres_do_ano(ano)
    print(f"Semestres para o ano {ano}: {semestres_do_ano}")

def obter_nomes_disciplinas():
    conexao = conecta_bd()

    if conexao:
        try:
            cursor = conexao.cursor()
            consulta = "SELECT DISTINCT nome FROM Disciplinas ORDER BY nome"
            cursor.execute(consulta)
            nomes_disciplinas = [nome[0] for nome in cursor.fetchall()]
            cursor.close()
            conexao.close()
            return nomes_disciplinas
        except Exception as erro:
            print(f"Erro ao obter nomes das disciplinas do banco de dados: {erro}")
            return []
    return []

def obter_niveis_do_banco(disciplina):
    conexao = conecta_bd()

    if conexao:
        try:
            cursor = conexao.cursor()
            consulta = """
                SELECT DISTINCT nivel_disciplina 
                FROM Disciplinas 
                WHERE nome = %s OR (ano IS NULL AND semestre IS NULL AND nome = %s)
                ORDER BY nivel_disciplina
            """
            cursor.execute(consulta, (disciplina, disciplina))
            niveis = [nivel[0] for nivel in cursor.fetchall()]
            cursor.close()
            conexao.close()
            return niveis
        except Exception as erro:
            print(f"Erro ao obter níveis do banco de dados: {erro}")
            return []
    return []


# Função para obter níveis por disciplina
def obter_niveis_por_disciplina(disciplina):
    conexao = conecta_bd()

    if conexao:
        try:
            cursor = conexao.cursor()
            consulta = """
                SELECT DISTINCT nivel_disciplina 
                FROM Disciplinas 
                WHERE nome = %s
                ORDER BY nivel_disciplina
            """
            cursor.execute(consulta, (disciplina,))
            niveis = [nivel[0] for nivel in cursor.fetchall()]
            cursor.close()
            conexao.close()
            return niveis
        except Exception as erro:
            print(f"Erro ao obter níveis do banco de dados para a disciplina {disciplina}: {erro}")
            return []
    return []

def obter_id_semestre_do_banco(ano, semestre):
    conexao = conecta_bd()
    id_semestre = None
    try:
        with conexao:
            with conexao.cursor() as cursor:
                cursor.execute(
                    sql.SQL("SELECT id_semestre FROM Semestre WHERE ano = %s AND semestre = %s;"),
                    (ano, semestre)
                )
                id_semestre = cursor.fetchone()[0]
    except Exception as erro:
        print(f'Erro ao obter ID do semestre: {erro}')
    finally:
        if conexao:
            conexao.close()
    return id_semestre

def obter_id_disciplina_do_banco(nome_disciplina):
    conexao = conecta_bd()
    id_disciplina = None
    try:
        with conexao:
            with conexao.cursor() as cursor:
                cursor.execute(
                    sql.SQL("SELECT id_disciplina FROM Disciplinas WHERE nome = %s;"),
                    (nome_disciplina,)
                )
                id_disciplina = cursor.fetchone()[0]
    except Exception as erro:
        print(f'Erro ao obter ID da disciplina: {erro}')
    finally:
        if conexao:
            conexao.close()
    return id_disciplina

def inserir_oferta_no_banco(id_semestre, id_disciplina, nivel):
    conexao = conecta_bd()
    try:
        with conexao:
            with conexao.cursor() as cursor:
                cursor.execute(
                    sql.SQL("INSERT INTO Ofertas (id_semestre, id_disciplina, nivel) VALUES (%s, %s, %s);"),
                    (id_semestre, id_disciplina, nivel)
                )
    except Exception as erro:
        print(f'Erro ao inserir oferta: {erro}')
    finally:
        if conexao:
            conexao.close()
            
def obter_ofertas_do_banco():
    conexao = conecta_bd()
    ofertas = []
    try:
        with conexao:
            with conexao.cursor() as cursor:
                # Consulta para obter informações da oferta, sem exibir IDs estrangeiros
                cursor.execute("""
                    SELECT Ofertas.id_oferta, Semestre.ano, Semestre.semestre, Disciplinas.nome, Ofertas.nivel
                    FROM Ofertas
                    INNER JOIN Semestre ON Ofertas.id_semestre = Semestre.id_semestre
                    INNER JOIN Disciplinas ON Ofertas.id_disciplina = Disciplinas.id_disciplina
                """)
                ofertas = cursor.fetchall()
    except Exception as erro:
        print(f'Erro ao obter ofertas: {erro}')
    finally:
        if conexao:
            conexao.close()
    return ofertas

def excluir_oferta_do_banco(id_oferta):
    conexao = conecta_bd()
    try:
        with conexao:
            with conexao.cursor() as cursor:
                cursor.execute(
                    sql.SQL("DELETE FROM Ofertas WHERE id_oferta = %s;"),
                    (id_oferta,)
                )
    except Exception as erro:
        print(f'Erro ao excluir oferta: {erro}')
    finally:
        if conexao:
            conexao.close()

#Final da Funções da Tela Cadastrar Oferta (Edson Rafael)

# Inicial da Funções da Tela Cadastro de Disciplina (Maycon Gabriel)
def obter_todas_disciplinas():
    conexao = conecta_bd()
    dados = []
    try:
        with conexao:
            with conexao.cursor() as cursor:
                cursor.execute("SELECT * FROM Disciplinas;")
                rows = cursor.fetchall()
                dados = [(row[0], row[1], row[2], row[3]) for row in rows]
    except Exception as erro:
        print(f'Erro ao obter disciplinas do banco: {erro}')
    finally:
        if conexao:
            conexao.close()
    return dados

def cadastrar_disciplina(nome, carga_horaria, nivel_disciplina):
    conexao = conecta_bd()
    id_disciplina = None
    try:
        with conexao:
            with conexao.cursor() as cursor:
                cursor.execute(
                    """
                    INSERT INTO Disciplinas (nome, carga_horaria, nivel_disciplina)
                    VALUES (%s, %s, %s)
                    RETURNING id_disciplina;
                    """,
                    (nome, carga_horaria, nivel_disciplina)
                )
                id_disciplina = cursor.fetchone()[0]
                print(f'Disciplina cadastrada com sucesso! ID: {id_disciplina}')
    except Exception as erro:
        print(f'Erro ao cadastrar disciplina: {erro}')
    finally:
        if conexao:
            conexao.close()
    return id_disciplina

def carregar_disciplinas_do_banco():
    conexao = conecta_bd()
    dados = []
    try:
        with conexao:
            with conexao.cursor() as cursor:
                cursor.execute("SELECT * FROM Disciplinas;")
                rows = cursor.fetchall()
                dados = [(row[0], row[1], row[2], row[3]) for row in rows]
    except Exception as erro:
        print(f'Erro ao carregar disciplinas do banco: {erro}')
    finally:
        if conexao:
            conexao.close()
    return dados

def remover_disciplina_do_banco(id_disciplina):
    conexao = conecta_bd()
    try:
        with conexao:
            with conexao.cursor() as cursor:
                cursor.execute(
                    "DELETE FROM Disciplinas WHERE id_disciplina = %s;",
                    (id_disciplina,)
                )
                print(f'Disciplina removida do banco com sucesso! ID: {id_disciplina}')
    except Exception as erro:
        print(f'Erro ao remover disciplina do banco: {erro}')
    finally:
        if conexao:
            conexao.close()
            
            
#Final da Funções da Tela Cadastro de Disciplina (Maycon Gabriel)

# Inicial da Funções da Tela Cadastro de (Vitória Matos)
# Adicione as seguintes funções no seu arquivo BancoDeDados.py:

def adicionar_semestre_ao_banco(ano, semestre):
    conexao = conecta_bd()
    id_semestre = None
    try:
        with conexao:
            with conexao.cursor() as cursor:
                cursor.execute(
                    sql.SQL("INSERT INTO Semestre (ano, semestre) VALUES (%s, %s) RETURNING id_semestre;"),
                    (ano, semestre)
                )
                id_semestre = cursor.fetchone()[0]
                print(f'Semestre adicionado com sucesso! ID: {id_semestre}')
    except Exception as erro:
        print(f'Erro ao adicionar semestre: {erro}')
    finally:
        if conexao:
            conexao.close()
    return id_semestre

def excluir_semestre_do_banco(id_semestre):
    conexao = conecta_bd()
    try:
        with conexao:
            with conexao.cursor() as cursor:
                cursor.execute(
                    sql.SQL("DELETE FROM Semestre WHERE id_semestre = %s;"),
                    (id_semestre,)
                )
                print(f'Semestre removido do banco com sucesso! ID: {id_semestre}')
    except Exception as erro:
        print(f'Erro ao remover semestre do banco: {erro}')
    finally:
        if conexao:
            conexao.close()

def obter_todos_semestres():
    conexao = conecta_bd()
    try:
        with conexao:
            with conexao.cursor() as cursor:
                cursor.execute("SELECT ano, semestre, id_semestre FROM Semestre;")
                return cursor.fetchall()
    except Exception as erro:
        print(f'Erro ao obter semestres: {erro}')
    finally:
        if conexao:
            conexao.close()
            
# Final da Funções da Tela Cadastro de (Vitória Matos)

# Inicio Funções da Tela de Gestão de Conteúdo das aulas (Giovana)
def inserir_dados(conexao, valores):
    try:
        with conexao.cursor() as cursor:
            cursor.execute("INSERT INTO Gestao_Aulas (id_semestre, id_disciplina, data, aulas, conteudo) VALUES (%s, %s, %s, %s, %s);", valores)
            conexao.commit()
            print('Inserido com sucesso!')
    except Exception as erro:
        print('Erro ao cadastrar:', erro)


def lista_aulas(conexao):
    try:
        with conexao.cursor() as cursor:
            cursor.execute("SELECT * FROM Gestao_Aulas ORDER BY id_conteudo_aula;")
            return cursor.fetchall()
    except Exception as erro:
        print('[ERRO]:', erro)

def deletar_dado(conexao, id_conteudo_aula):
    try:
        with conexao.cursor() as cursor:
            cursor.execute("DELETE FROM Gestao_Aulas WHERE id_conteudo_aula = %s;", (id_conteudo_aula,))
            conexao.commit()
            print('Dado deletado com sucesso!')
    except Exception as erro:
        print('Erro ao deletar dado:', erro)


def atualizar_dados(conexao, id_conteudo_aula, novos_valores):
    try:
        with conexao.cursor() as cursor:
            # Crie a string SQL para a atualização
            sql_atualizacao = """
                UPDATE Gestao_Aulas
                SET id_semestre = %s, id_disciplina = %s, data = %s, aulas = %s, conteudo = %s
                WHERE id_conteudo_aula = %s;
            """
            # Adicione os novos valores ao final da tupla
            valores_atualizacao = novos_valores + (id_conteudo_aula,)
            
            # Execute a atualização
            cursor.execute(sql_atualizacao, valores_atualizacao)
            conexao.commit()
            
            print('Dados atualizados com sucesso!')
    except Exception as erro:
        print('Erro ao atualizar dados:', erro)


    # Atualizar dados (exemplo: atualizar o primeiro dado)
    id_conteudo_aula_para_atualizar = 1
    novos_valores = (2, 2, '2023-01-02', 4, 'Conteúdo atualizado')
    atualizar_dados(conexao, id_conteudo_aula_para_atualizar, novos_valores)

    # Verificar se os dados foram atualizados
    dados_atualizados = lista_aulas(conexao)
    print("Dados Atualizados:")
    print(dados_atualizados)

    # Inserir dados
    valores_insercao = (1, 1, '2023-01-01', 3, 'Conteúdo da aula 1')
    inserir_dados(conexao, valores_insercao)

    # Selecionar dados
    dados_selecionados = lista_aulas(conexao)
    print("Dados Selecionados:")
    print(dados_selecionados)

    # Deletar dado (exemplo: deletar o primeiro dado)
    deletar_dado(conexao, 1)

conexao = conecta_bd()

#Final da Funções da Tela de Gestão de Conteúdo das aulas (Giovana)
def inserir_dados(conexao, valores):
    try:
        with conexao.cursor() as cursor:
            cursor.execute("INSERT INTO Gestao_Aulas (id_semestre, id_disciplina, data, aulas, conteudo) VALUES (%s, %s, %s, %s, %s);", valores)
            conexao.commit()
            print('Inserido com sucesso!')
    except Exception as erro:
        print('Erro ao cadastrar:', erro)


def lista_aulas(conexao):
    try:
        with conexao.cursor() as cursor:
            cursor.execute("SELECT * FROM Gestao_Aulas ORDER BY id_conteudo_aula;")
            return cursor.fetchall()
    except Exception as erro:
        print('[ERRO]:', erro)

def deletar_dado(conexao, id_conteudo_aula):
    try:
        with conexao.cursor() as cursor:
            cursor.execute("DELETE FROM Gestao_Aulas WHERE id_conteudo_aula = %s;", (id_conteudo_aula,))
            conexao.commit()
            print('Dado deletado com sucesso!')
    except Exception as erro:
        print('Erro ao deletar dado:', erro)


def atualizar_dados(conexao, id_conteudo_aula, novos_valores):
    try:
        with conexao.cursor() as cursor:
            # Crie a string SQL para a atualização
            sql_atualizacao = """
                UPDATE Gestao_Aulas
                SET id_semestre = %s, id_disciplina = %s, data = %s, aulas = %s, conteudo = %s
                WHERE id_conteudo_aula = %s;
            """
            # Adicione os novos valores ao final da tupla
            valores_atualizacao = novos_valores + (id_conteudo_aula,)
            
            # Execute a atualização
            cursor.execute(sql_atualizacao, valores_atualizacao)
            conexao.commit()
            
            print('Dados atualizados com sucesso!')
    except Exception as erro:
        print('Erro ao atualizar dados:', erro)

def executa_operacoes_exemplo(conexao):
    # Atualizar dados (exemplo: atualizar o primeiro dado)
    id_conteudo_aula_para_atualizar = 1
    novos_valores = (2, 2, '2023-01-02', 4, 'Conteúdo atualizado')
    atualizar_dados(conexao, id_conteudo_aula_para_atualizar, novos_valores)

    # Verificar se os dados foram atualizados
    dados_atualizados = lista_aulas(conexao)
    print("Dados Atualizados:")
    print(dados_atualizados)

    # Inserir dados
    valores_insercao = (1, 1, '2023-01-01', 3, 'Conteúdo da aula 1')
    inserir_dados(conexao, valores_insercao)

    # Selecionar dados
    dados_selecionados = lista_aulas(conexao)
    print("Dados Selecionados:")
    print(dados_selecionados)

# Chame a função se necessário
# executa_operacoes_exemplo(conexao)
conexao = conecta_bd()

#Final da Funções da Tela de Gestão de Conteúdo das aulas (Giovana)

# Alice 
#funçôes da tela de cronograma da (alice)
def adicionar_datas_ao_banco(semestre, disciplina, dia_inicio, dia_termino):
    conexao = conecta_bd()
    try:
        with conexao:
            with conexao.cursor() as cursor:
                cursor.execute(
                    sql.SQL("INSERT INTO cronograma (id_semestre, nome_disciplina, dia_inicio, dia_termino) VALUES (%s, %s, %s, %s);"),
                    (semestre, disciplina, dia_inicio, dia_termino)
                )
                print("Datas adicionadas ao banco de dados com sucesso!")
    except Exception as erro:
        print(f'Erro ao adicionar datas ao banco de dados: {erro}')
    finally:
        if conexao:
            conexao.close()
            
# Final

conexao = conecta_bd()